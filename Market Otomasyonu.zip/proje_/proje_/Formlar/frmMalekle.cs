﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proje_
{
    public partial class frmMalekle : Form
    {
        public frmMalekle()
        {
            InitializeComponent();
        }

        private void frmMalekle_Load(object sender, EventArgs e)
        {

        }
    }
}
