﻿namespace proje_.Formlar
{
    partial class frmUrunEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboUrunadi = new System.Windows.Forms.ComboBox();
            this.fKTBLModelTBLMarkaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLMarkaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.sondataset = new proje_.sondataset();
            this.fKTBLModelTBLMarkaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLMarkaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tumTablolarDataset = new proje_.TumTablolarDataset();
            this.urunBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gıdaDataSet = new proje_.gıdaDataSet();
            this.fKTBLModelTBLMarkaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBLMarkaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboMarka = new System.Windows.Forms.ComboBox();
            this.dateGelis = new System.Windows.Forms.DateTimePicker();
            this.dateUretim = new System.Windows.Forms.DateTimePicker();
            this.txtAlisfiyati = new System.Windows.Forms.TextBox();
            this.txtsatisfiyati = new System.Windows.Forms.TextBox();
            this.txtkdv = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnEkle = new System.Windows.Forms.Button();
            this.btnIptal = new System.Windows.Forms.Button();
            this.btnResimsec = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tBLMarkaTableAdapter = new proje_.gıdaDataSetTableAdapters.TBLMarkaTableAdapter();
            this.tBLModelTableAdapter = new proje_.gıdaDataSetTableAdapters.TBLModelTableAdapter();
            this.urunBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.urunTableAdapter = new proje_.gıdaDataSetTableAdapters.UrunTableAdapter();
            this.fKTBLModelTBLMarkaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.txtMiktar = new System.Windows.Forms.TextBox();
            this.tBLMarkaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gıdaDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.urunBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.urunBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.urunTableAdapter1 = new proje_.TumTablolarDatasetTableAdapters.UrunTableAdapter();
            this.urunBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLModelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLModelTableAdapter1 = new proje_.TumTablolarDatasetTableAdapters.TBLModelTableAdapter();
            this.tBLMarkaTableAdapter1 = new proje_.TumTablolarDatasetTableAdapters.TBLMarkaTableAdapter();
            this.tBLMarkaTableAdapter2 = new proje_.sondatasetTableAdapters.TBLMarkaTableAdapter();
            this.tBLModelTableAdapter2 = new proje_.sondatasetTableAdapters.TBLModelTableAdapter();
            this.tBLMarkaBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLModelBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sondataset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tumTablolarDataset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gıdaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gıdaDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLModelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLModelBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // comboUrunadi
            // 
            this.comboUrunadi.DataSource = this.tBLModelBindingSource2;
            this.comboUrunadi.DisplayMember = "urun";
            this.comboUrunadi.FormattingEnabled = true;
            this.comboUrunadi.Location = new System.Drawing.Point(195, 80);
            this.comboUrunadi.Name = "comboUrunadi";
            this.comboUrunadi.Size = new System.Drawing.Size(196, 24);
            this.comboUrunadi.TabIndex = 0;
            // 
            // fKTBLModelTBLMarkaBindingSource3
            // 
            this.fKTBLModelTBLMarkaBindingSource3.DataMember = "FK_TBLModel_TBLMarka";
            this.fKTBLModelTBLMarkaBindingSource3.DataSource = this.tBLMarkaBindingSource3;
            // 
            // tBLMarkaBindingSource3
            // 
            this.tBLMarkaBindingSource3.DataMember = "TBLMarka";
            this.tBLMarkaBindingSource3.DataSource = this.sondataset;
            // 
            // sondataset
            // 
            this.sondataset.DataSetName = "sondataset";
            this.sondataset.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fKTBLModelTBLMarkaBindingSource2
            // 
            this.fKTBLModelTBLMarkaBindingSource2.DataMember = "FK_TBLModel_TBLMarka";
            this.fKTBLModelTBLMarkaBindingSource2.DataSource = this.tBLMarkaBindingSource2;
            // 
            // tBLMarkaBindingSource2
            // 
            this.tBLMarkaBindingSource2.DataMember = "TBLMarka";
            this.tBLMarkaBindingSource2.DataSource = this.tumTablolarDataset;
            // 
            // tumTablolarDataset
            // 
            this.tumTablolarDataset.DataSetName = "TumTablolarDataset";
            this.tumTablolarDataset.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // urunBindingSource1
            // 
            this.urunBindingSource1.DataMember = "Urun";
            this.urunBindingSource1.DataSource = this.gıdaDataSet;
            // 
            // gıdaDataSet
            // 
            this.gıdaDataSet.DataSetName = "gıdaDataSet";
            this.gıdaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fKTBLModelTBLMarkaBindingSource
            // 
            this.fKTBLModelTBLMarkaBindingSource.DataMember = "FK_TBLModel_TBLMarka";
            this.fKTBLModelTBLMarkaBindingSource.DataSource = this.tBLMarkaBindingSource;
            // 
            // tBLMarkaBindingSource
            // 
            this.tBLMarkaBindingSource.DataMember = "TBLMarka";
            this.tBLMarkaBindingSource.DataSource = this.gıdaDataSet;
            // 
            // comboMarka
            // 
            this.comboMarka.DataSource = this.tBLMarkaBindingSource4;
            this.comboMarka.DisplayMember = "marka";
            this.comboMarka.FormattingEnabled = true;
            this.comboMarka.Location = new System.Drawing.Point(195, 29);
            this.comboMarka.Name = "comboMarka";
            this.comboMarka.Size = new System.Drawing.Size(196, 24);
            this.comboMarka.TabIndex = 0;
            // 
            // dateGelis
            // 
            this.dateGelis.Location = new System.Drawing.Point(195, 176);
            this.dateGelis.Name = "dateGelis";
            this.dateGelis.Size = new System.Drawing.Size(196, 22);
            this.dateGelis.TabIndex = 2;
            // 
            // dateUretim
            // 
            this.dateUretim.Location = new System.Drawing.Point(195, 125);
            this.dateUretim.Name = "dateUretim";
            this.dateUretim.Size = new System.Drawing.Size(196, 22);
            this.dateUretim.TabIndex = 2;
            // 
            // txtAlisfiyati
            // 
            this.txtAlisfiyati.Location = new System.Drawing.Point(195, 229);
            this.txtAlisfiyati.Name = "txtAlisfiyati";
            this.txtAlisfiyati.Size = new System.Drawing.Size(196, 22);
            this.txtAlisfiyati.TabIndex = 3;
            // 
            // txtsatisfiyati
            // 
            this.txtsatisfiyati.Location = new System.Drawing.Point(195, 275);
            this.txtsatisfiyati.Name = "txtsatisfiyati";
            this.txtsatisfiyati.Size = new System.Drawing.Size(196, 22);
            this.txtsatisfiyati.TabIndex = 3;
            // 
            // txtkdv
            // 
            this.txtkdv.Location = new System.Drawing.Point(195, 318);
            this.txtkdv.Name = "txtkdv";
            this.txtkdv.Size = new System.Drawing.Size(196, 22);
            this.txtkdv.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(429, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(137, 108);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btnEkle
            // 
            this.btnEkle.Location = new System.Drawing.Point(162, 412);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(91, 44);
            this.btnEkle.TabIndex = 5;
            this.btnEkle.Text = "Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // btnIptal
            // 
            this.btnIptal.Location = new System.Drawing.Point(279, 412);
            this.btnIptal.Name = "btnIptal";
            this.btnIptal.Size = new System.Drawing.Size(91, 44);
            this.btnIptal.TabIndex = 5;
            this.btnIptal.Text = "İptal";
            this.btnIptal.UseVisualStyleBackColor = true;
            this.btnIptal.Click += new System.EventHandler(this.btnIptal_Click);
            // 
            // btnResimsec
            // 
            this.btnResimsec.Location = new System.Drawing.Point(452, 170);
            this.btnResimsec.Name = "btnResimsec";
            this.btnResimsec.Size = new System.Drawing.Size(98, 38);
            this.btnResimsec.TabIndex = 5;
            this.btnResimsec.Text = "Resim Seç";
            this.btnResimsec.UseVisualStyleBackColor = true;
            this.btnResimsec.Click += new System.EventHandler(this.btnResimsec_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Marka";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ürün Adı";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Üretim Tarihi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Alış Tarihi";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Alış fiyatı";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 275);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "Satış Fiyatı";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 16);
            this.label9.TabIndex = 6;
            this.label9.Text = "Kdv";
            // 
            // tBLMarkaTableAdapter
            // 
            this.tBLMarkaTableAdapter.ClearBeforeFill = true;
            // 
            // tBLModelTableAdapter
            // 
            this.tBLModelTableAdapter.ClearBeforeFill = true;
            // 
            // urunBindingSource
            // 
            this.urunBindingSource.DataMember = "Urun";
            this.urunBindingSource.DataSource = this.gıdaDataSet;
            // 
            // urunTableAdapter
            // 
            this.urunTableAdapter.ClearBeforeFill = true;
            // 
            // fKTBLModelTBLMarkaBindingSource1
            // 
            this.fKTBLModelTBLMarkaBindingSource1.DataMember = "FK_TBLModel_TBLMarka";
            this.fKTBLModelTBLMarkaBindingSource1.DataSource = this.tBLMarkaBindingSource;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 355);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Miktar";
            // 
            // txtMiktar
            // 
            this.txtMiktar.Location = new System.Drawing.Point(195, 352);
            this.txtMiktar.Name = "txtMiktar";
            this.txtMiktar.Size = new System.Drawing.Size(196, 22);
            this.txtMiktar.TabIndex = 3;
            // 
            // tBLMarkaBindingSource1
            // 
            this.tBLMarkaBindingSource1.DataMember = "TBLMarka";
            this.tBLMarkaBindingSource1.DataSource = this.gıdaDataSet;
            // 
            // gıdaDataSetBindingSource
            // 
            this.gıdaDataSetBindingSource.DataSource = this.gıdaDataSet;
            this.gıdaDataSetBindingSource.Position = 0;
            // 
            // urunBindingSource2
            // 
            this.urunBindingSource2.DataMember = "Urun";
            this.urunBindingSource2.DataSource = this.gıdaDataSet;
            // 
            // tBLModelBindingSource
            // 
            this.tBLModelBindingSource.DataMember = "TBLModel";
            this.tBLModelBindingSource.DataSource = this.gıdaDataSet;
            // 
            // urunBindingSource3
            // 
            this.urunBindingSource3.DataMember = "Urun";
            this.urunBindingSource3.DataSource = this.tumTablolarDataset;
            // 
            // urunTableAdapter1
            // 
            this.urunTableAdapter1.ClearBeforeFill = true;
            // 
            // urunBindingSource4
            // 
            this.urunBindingSource4.DataMember = "Urun";
            this.urunBindingSource4.DataSource = this.tumTablolarDataset;
            // 
            // tBLModelBindingSource1
            // 
            this.tBLModelBindingSource1.DataMember = "TBLModel";
            this.tBLModelBindingSource1.DataSource = this.tumTablolarDataset;
            // 
            // tBLModelTableAdapter1
            // 
            this.tBLModelTableAdapter1.ClearBeforeFill = true;
            // 
            // tBLMarkaTableAdapter1
            // 
            this.tBLMarkaTableAdapter1.ClearBeforeFill = true;
            // 
            // tBLMarkaTableAdapter2
            // 
            this.tBLMarkaTableAdapter2.ClearBeforeFill = true;
            // 
            // tBLModelTableAdapter2
            // 
            this.tBLModelTableAdapter2.ClearBeforeFill = true;
            // 
            // tBLMarkaBindingSource4
            // 
            this.tBLMarkaBindingSource4.DataMember = "TBLMarka";
            this.tBLMarkaBindingSource4.DataSource = this.gıdaDataSet;
            // 
            // tBLModelBindingSource2
            // 
            this.tBLModelBindingSource2.DataMember = "TBLModel";
            this.tBLModelBindingSource2.DataSource = this.gıdaDataSet;
            // 
            // frmUrunEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(640, 599);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnResimsec);
            this.Controls.Add(this.btnIptal);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtMiktar);
            this.Controls.Add(this.txtkdv);
            this.Controls.Add(this.txtsatisfiyati);
            this.Controls.Add(this.txtAlisfiyati);
            this.Controls.Add(this.dateUretim);
            this.Controls.Add(this.dateGelis);
            this.Controls.Add(this.comboMarka);
            this.Controls.Add(this.comboUrunadi);
            this.Name = "frmUrunEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ÜRÜN EKLEME SAYFASI";
            this.Load += new System.EventHandler(this.frmUrunEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sondataset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tumTablolarDataset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gıdaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKTBLModelTBLMarkaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gıdaDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLModelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLMarkaBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLModelBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboUrunadi;
        private System.Windows.Forms.ComboBox comboMarka;
        private System.Windows.Forms.DateTimePicker dateGelis;
        private System.Windows.Forms.DateTimePicker dateUretim;
        private System.Windows.Forms.TextBox txtAlisfiyati;
        private System.Windows.Forms.TextBox txtsatisfiyati;
        private System.Windows.Forms.TextBox txtkdv;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Button btnIptal;
        private System.Windows.Forms.Button btnResimsec;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private gıdaDataSet gıdaDataSet;
        private System.Windows.Forms.BindingSource tBLMarkaBindingSource;
        private gıdaDataSetTableAdapters.TBLMarkaTableAdapter tBLMarkaTableAdapter;
        private System.Windows.Forms.BindingSource fKTBLModelTBLMarkaBindingSource;
        private gıdaDataSetTableAdapters.TBLModelTableAdapter tBLModelTableAdapter;
        private System.Windows.Forms.BindingSource urunBindingSource;
        private gıdaDataSetTableAdapters.UrunTableAdapter urunTableAdapter;
        private System.Windows.Forms.BindingSource fKTBLModelTBLMarkaBindingSource1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMiktar;
        private System.Windows.Forms.BindingSource urunBindingSource1;
        private System.Windows.Forms.BindingSource tBLMarkaBindingSource1;
        private System.Windows.Forms.BindingSource gıdaDataSetBindingSource;
        private System.Windows.Forms.BindingSource urunBindingSource2;
        private System.Windows.Forms.BindingSource tBLModelBindingSource;
        private TumTablolarDataset tumTablolarDataset;
        private System.Windows.Forms.BindingSource urunBindingSource3;
        private TumTablolarDatasetTableAdapters.UrunTableAdapter urunTableAdapter1;
        private System.Windows.Forms.BindingSource urunBindingSource4;
        private System.Windows.Forms.BindingSource tBLModelBindingSource1;
        private TumTablolarDatasetTableAdapters.TBLModelTableAdapter tBLModelTableAdapter1;
        private System.Windows.Forms.BindingSource tBLMarkaBindingSource2;
        private TumTablolarDatasetTableAdapters.TBLMarkaTableAdapter tBLMarkaTableAdapter1;
        private System.Windows.Forms.BindingSource fKTBLModelTBLMarkaBindingSource2;
        private sondataset sondataset;
        private System.Windows.Forms.BindingSource tBLMarkaBindingSource3;
        private sondatasetTableAdapters.TBLMarkaTableAdapter tBLMarkaTableAdapter2;
        private System.Windows.Forms.BindingSource fKTBLModelTBLMarkaBindingSource3;
        private sondatasetTableAdapters.TBLModelTableAdapter tBLModelTableAdapter2;
        private System.Windows.Forms.BindingSource tBLModelBindingSource2;
        private System.Windows.Forms.BindingSource tBLMarkaBindingSource4;
    }
}