﻿namespace proje_
{
    partial class formAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAnaSayfa));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCikis = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnUrunekle = new System.Windows.Forms.Button();
            this.btnMarkaekle = new System.Windows.Forms.Button();
            this.btnYapılanSatislar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnMusteriListele = new System.Windows.Forms.Button();
            this.btnMusteriEkle = new System.Windows.Forms.Button();
            this.btnKullanıcıListele = new System.Windows.Forms.Button();
            this.btnKullanıcıEkle = new System.Windows.Forms.Button();
            this.btnMalListele = new System.Windows.Forms.Button();
            this.btnMalEkle = new System.Windows.Forms.Button();
            this.panelSayfalar = new System.Windows.Forms.Panel();
            this.btnDoviz = new System.Windows.Forms.Button();
            this.btnUlas = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Cyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnUlas);
            this.panel1.Controls.Add(this.btnDoviz);
            this.panel1.Controls.Add(this.btnCikis);
            this.panel1.Controls.Add(this.btnUrunekle);
            this.panel1.Controls.Add(this.btnMarkaekle);
            this.panel1.Controls.Add(this.btnYapılanSatislar);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnMusteriListele);
            this.panel1.Controls.Add(this.btnMusteriEkle);
            this.panel1.Controls.Add(this.btnKullanıcıListele);
            this.panel1.Controls.Add(this.btnKullanıcıEkle);
            this.panel1.Controls.Add(this.btnMalListele);
            this.panel1.Controls.Add(this.btnMalEkle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1311, 115);
            this.panel1.TabIndex = 0;
            // 
            // btnCikis
            // 
            this.btnCikis.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCikis.ImageKey = "indir.png";
            this.btnCikis.ImageList = this.ımageList1;
            this.btnCikis.Location = new System.Drawing.Point(1209, 3);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(89, 87);
            this.btnCikis.TabIndex = 2;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "sale1.jpeg");
            this.ımageList1.Images.SetKeyName(1, "sales.jpeg");
            this.ımageList1.Images.SetKeyName(2, "müşteri ekle.jpeg");
            this.ımageList1.Images.SetKeyName(3, "müşteri listele.jpeg");
            this.ımageList1.Images.SetKeyName(4, "kullanıcı ekle.jpeg");
            this.ımageList1.Images.SetKeyName(5, "kullanıcı listele.jpeg");
            this.ımageList1.Images.SetKeyName(6, "ürün ekle.jpeg");
            this.ımageList1.Images.SetKeyName(7, "ürün listele.jpeg");
            this.ımageList1.Images.SetKeyName(8, "indir.png");
            this.ımageList1.Images.SetKeyName(9, "827d64e39d0d6acc50e9cded154c4080.jpg");
            this.ımageList1.Images.SetKeyName(10, "9708518178866.jpg");
            this.ımageList1.Images.SetKeyName(11, "doviz.png");
            this.ımageList1.Images.SetKeyName(12, "bize ulsaşın.png");
            // 
            // btnUrunekle
            // 
            this.btnUrunekle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUrunekle.ImageKey = "9708518178866.jpg";
            this.btnUrunekle.ImageList = this.ımageList1;
            this.btnUrunekle.Location = new System.Drawing.Point(915, 3);
            this.btnUrunekle.Name = "btnUrunekle";
            this.btnUrunekle.Size = new System.Drawing.Size(89, 87);
            this.btnUrunekle.TabIndex = 1;
            this.btnUrunekle.Text = "Ürün Ekle";
            this.btnUrunekle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUrunekle.UseVisualStyleBackColor = true;
            this.btnUrunekle.Click += new System.EventHandler(this.btnUrunekle_Click);
            // 
            // btnMarkaekle
            // 
            this.btnMarkaekle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMarkaekle.ImageKey = "827d64e39d0d6acc50e9cded154c4080.jpg";
            this.btnMarkaekle.ImageList = this.ımageList1;
            this.btnMarkaekle.Location = new System.Drawing.Point(820, 3);
            this.btnMarkaekle.Name = "btnMarkaekle";
            this.btnMarkaekle.Size = new System.Drawing.Size(89, 87);
            this.btnMarkaekle.TabIndex = 1;
            this.btnMarkaekle.Text = "Marka Ekle";
            this.btnMarkaekle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMarkaekle.UseVisualStyleBackColor = true;
            this.btnMarkaekle.Click += new System.EventHandler(this.btnMarkaekle_Click);
            // 
            // btnYapılanSatislar
            // 
            this.btnYapılanSatislar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnYapılanSatislar.ImageKey = "sales.jpeg";
            this.btnYapılanSatislar.ImageList = this.ımageList1;
            this.btnYapılanSatislar.Location = new System.Drawing.Point(725, 3);
            this.btnYapılanSatislar.Name = "btnYapılanSatislar";
            this.btnYapılanSatislar.Size = new System.Drawing.Size(89, 87);
            this.btnYapılanSatislar.TabIndex = 1;
            this.btnYapılanSatislar.Text = "Yapılan Satışlar";
            this.btnYapılanSatislar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnYapılanSatislar.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.ImageKey = "sale1.jpeg";
            this.button1.ImageList = this.ımageList1;
            this.button1.Location = new System.Drawing.Point(623, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 87);
            this.button1.TabIndex = 1;
            this.button1.Text = "Satış Yap";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnMusteriListele
            // 
            this.btnMusteriListele.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMusteriListele.ImageKey = "müşteri listele.jpeg";
            this.btnMusteriListele.ImageList = this.ımageList1;
            this.btnMusteriListele.Location = new System.Drawing.Point(521, 3);
            this.btnMusteriListele.Name = "btnMusteriListele";
            this.btnMusteriListele.Size = new System.Drawing.Size(89, 87);
            this.btnMusteriListele.TabIndex = 1;
            this.btnMusteriListele.Text = "Müşteri Listele";
            this.btnMusteriListele.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMusteriListele.UseVisualStyleBackColor = true;
            this.btnMusteriListele.Click += new System.EventHandler(this.btnMusteriListele_Click);
            // 
            // btnMusteriEkle
            // 
            this.btnMusteriEkle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMusteriEkle.ImageKey = "müşteri ekle.jpeg";
            this.btnMusteriEkle.ImageList = this.ımageList1;
            this.btnMusteriEkle.Location = new System.Drawing.Point(419, 3);
            this.btnMusteriEkle.Name = "btnMusteriEkle";
            this.btnMusteriEkle.Size = new System.Drawing.Size(89, 87);
            this.btnMusteriEkle.TabIndex = 1;
            this.btnMusteriEkle.Text = "Müşteri Ekle";
            this.btnMusteriEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMusteriEkle.UseVisualStyleBackColor = true;
            this.btnMusteriEkle.Click += new System.EventHandler(this.btnMusteriEkle_Click);
            // 
            // btnKullanıcıListele
            // 
            this.btnKullanıcıListele.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKullanıcıListele.ImageKey = "kullanıcı listele.jpeg";
            this.btnKullanıcıListele.ImageList = this.ımageList1;
            this.btnKullanıcıListele.Location = new System.Drawing.Point(317, 3);
            this.btnKullanıcıListele.Name = "btnKullanıcıListele";
            this.btnKullanıcıListele.Size = new System.Drawing.Size(89, 87);
            this.btnKullanıcıListele.TabIndex = 1;
            this.btnKullanıcıListele.Text = "Kullanıcı Listele";
            this.btnKullanıcıListele.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKullanıcıListele.UseVisualStyleBackColor = true;
            this.btnKullanıcıListele.Click += new System.EventHandler(this.btnKullanıcıListele_Click);
            // 
            // btnKullanıcıEkle
            // 
            this.btnKullanıcıEkle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKullanıcıEkle.ImageKey = "kullanıcı ekle.jpeg";
            this.btnKullanıcıEkle.ImageList = this.ımageList1;
            this.btnKullanıcıEkle.Location = new System.Drawing.Point(215, 3);
            this.btnKullanıcıEkle.Name = "btnKullanıcıEkle";
            this.btnKullanıcıEkle.Size = new System.Drawing.Size(89, 87);
            this.btnKullanıcıEkle.TabIndex = 1;
            this.btnKullanıcıEkle.Text = "Kullanıcı Ekle";
            this.btnKullanıcıEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKullanıcıEkle.UseVisualStyleBackColor = true;
            this.btnKullanıcıEkle.Click += new System.EventHandler(this.btnKullanıcıEkle_Click);
            // 
            // btnMalListele
            // 
            this.btnMalListele.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMalListele.ImageKey = "ürün listele.jpeg";
            this.btnMalListele.ImageList = this.ımageList1;
            this.btnMalListele.Location = new System.Drawing.Point(113, 3);
            this.btnMalListele.Name = "btnMalListele";
            this.btnMalListele.Size = new System.Drawing.Size(89, 87);
            this.btnMalListele.TabIndex = 1;
            this.btnMalListele.Text = "Ürün Listele";
            this.btnMalListele.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMalListele.UseVisualStyleBackColor = true;
            this.btnMalListele.Click += new System.EventHandler(this.btnMalListele_Click);
            // 
            // btnMalEkle
            // 
            this.btnMalEkle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMalEkle.ImageKey = "ürün ekle.jpeg";
            this.btnMalEkle.ImageList = this.ımageList1;
            this.btnMalEkle.Location = new System.Drawing.Point(11, 3);
            this.btnMalEkle.Name = "btnMalEkle";
            this.btnMalEkle.Size = new System.Drawing.Size(89, 87);
            this.btnMalEkle.TabIndex = 1;
            this.btnMalEkle.Text = "Ürün Ekle";
            this.btnMalEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMalEkle.UseVisualStyleBackColor = true;
            this.btnMalEkle.Click += new System.EventHandler(this.btnMalEkle_Click);
            // 
            // panelSayfalar
            // 
            this.panelSayfalar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSayfalar.Location = new System.Drawing.Point(0, 115);
            this.panelSayfalar.Name = "panelSayfalar";
            this.panelSayfalar.Size = new System.Drawing.Size(1311, 668);
            this.panelSayfalar.TabIndex = 2;
            // 
            // btnDoviz
            // 
            this.btnDoviz.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDoviz.ImageKey = "doviz.png";
            this.btnDoviz.ImageList = this.ımageList1;
            this.btnDoviz.Location = new System.Drawing.Point(1010, 3);
            this.btnDoviz.Name = "btnDoviz";
            this.btnDoviz.Size = new System.Drawing.Size(89, 87);
            this.btnDoviz.TabIndex = 3;
            this.btnDoviz.Text = "Döviz Kuru";
            this.btnDoviz.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDoviz.UseVisualStyleBackColor = true;
            this.btnDoviz.Click += new System.EventHandler(this.btnDoviz_Click);
            // 
            // btnUlas
            // 
            this.btnUlas.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUlas.ImageKey = "bize ulsaşın.png";
            this.btnUlas.ImageList = this.ımageList1;
            this.btnUlas.Location = new System.Drawing.Point(1105, 3);
            this.btnUlas.Name = "btnUlas";
            this.btnUlas.Size = new System.Drawing.Size(89, 87);
            this.btnUlas.TabIndex = 4;
            this.btnUlas.Text = "Bize Ulaşın";
            this.btnUlas.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUlas.UseVisualStyleBackColor = true;
            this.btnUlas.Click += new System.EventHandler(this.btnUlas_Click);
            // 
            // formAnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1311, 783);
            this.Controls.Add(this.panelSayfalar);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.Name = "formAnaSayfa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ÜRÜN SATIŞ ANASAYFASI";
            this.Load += new System.EventHandler(this.formAnaSayfa_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnYapılanSatislar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnMusteriListele;
        private System.Windows.Forms.Button btnMusteriEkle;
        private System.Windows.Forms.Button btnKullanıcıListele;
        private System.Windows.Forms.Button btnKullanıcıEkle;
        private System.Windows.Forms.Button btnMalListele;
        private System.Windows.Forms.Button btnMalEkle;
        private System.Windows.Forms.Panel panelSayfalar;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button btnUrunekle;
        private System.Windows.Forms.Button btnMarkaekle;
        private System.Windows.Forms.Button btnUlas;
        private System.Windows.Forms.Button btnDoviz;
    }
}

