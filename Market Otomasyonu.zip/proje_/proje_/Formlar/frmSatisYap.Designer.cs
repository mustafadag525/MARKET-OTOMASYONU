﻿namespace proje_.Formlar
{
    partial class frmSatisYap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMusteriBorc = new System.Windows.Forms.Button();
            this.lblKdv = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnSatisIptal = new System.Windows.Forms.Button();
            this.btnSatisOnay = new System.Windows.Forms.Button();
            this.txtParaUstu = new System.Windows.Forms.TextBox();
            this.txtOdenen = new System.Windows.Forms.TextBox();
            this.comboOdeme = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblToplamTutar = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblKayitSayisi = new System.Windows.Forms.Label();
            this.btnYapılanSatislar = new System.Windows.Forms.Button();
            this.btnFiyatGor = new System.Windows.Forms.Button();
            this.btnUrunIade = new System.Windows.Forms.Button();
            this.btnAnaSayfa = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panelMusteri = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtAdSoyad = new System.Windows.Forms.TextBox();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.txtMusteriIdAra = new System.Windows.Forms.TextBox();
            this.panelUrun = new System.Windows.Forms.Panel();
            this.btnSepeteEkle = new System.Windows.Forms.Button();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtToplamFiyat = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMarka = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKdv = new System.Windows.Forms.TextBox();
            this.txtBirimFiyat = new System.Windows.Forms.TextBox();
            this.txtMiktar = new System.Windows.Forms.TextBox();
            this.txtUrun = new System.Windows.Forms.TextBox();
            this.txtMalId = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Sil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Arttır = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Azalt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panelMusteri.SuspendLayout();
            this.panelUrun.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMusteriBorc
            // 
            this.btnMusteriBorc.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnMusteriBorc.Location = new System.Drawing.Point(128, 15);
            this.btnMusteriBorc.Name = "btnMusteriBorc";
            this.btnMusteriBorc.Size = new System.Drawing.Size(96, 57);
            this.btnMusteriBorc.TabIndex = 0;
            this.btnMusteriBorc.Text = "Müşteri Borç(f6)";
            this.btnMusteriBorc.UseVisualStyleBackColor = false;
            // 
            // lblKdv
            // 
            this.lblKdv.BackColor = System.Drawing.Color.Red;
            this.lblKdv.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKdv.Location = new System.Drawing.Point(203, 15);
            this.lblKdv.Name = "lblKdv";
            this.lblKdv.Size = new System.Drawing.Size(173, 33);
            this.lblKdv.TabIndex = 2;
            this.lblKdv.Text = "25,25";
            this.lblKdv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(4, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(192, 33);
            this.label13.TabIndex = 1;
            this.label13.Text = "Toplam Tutar";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(24, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 33);
            this.label12.TabIndex = 0;
            this.label12.Text = "KDV";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(467, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 24);
            this.label16.TabIndex = 5;
            this.label16.Text = "TL";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(467, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 24);
            this.label17.TabIndex = 5;
            this.label17.Text = "TL";
            // 
            // btnSatisIptal
            // 
            this.btnSatisIptal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnSatisIptal.Location = new System.Drawing.Point(512, 75);
            this.btnSatisIptal.Name = "btnSatisIptal";
            this.btnSatisIptal.Size = new System.Drawing.Size(93, 46);
            this.btnSatisIptal.TabIndex = 2;
            this.btnSatisIptal.Text = "Satış iptal(f5)";
            this.btnSatisIptal.UseVisualStyleBackColor = false;
            this.btnSatisIptal.Click += new System.EventHandler(this.btnSatisIptal_Click);
            // 
            // btnSatisOnay
            // 
            this.btnSatisOnay.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnSatisOnay.Location = new System.Drawing.Point(512, 11);
            this.btnSatisOnay.Name = "btnSatisOnay";
            this.btnSatisOnay.Size = new System.Drawing.Size(93, 46);
            this.btnSatisOnay.TabIndex = 2;
            this.btnSatisOnay.Text = "Satış Onay(f4)";
            this.btnSatisOnay.UseVisualStyleBackColor = false;
            this.btnSatisOnay.Click += new System.EventHandler(this.btnSatisOnay_Click);
            // 
            // txtParaUstu
            // 
            this.txtParaUstu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtParaUstu.Location = new System.Drawing.Point(361, 88);
            this.txtParaUstu.Name = "txtParaUstu";
            this.txtParaUstu.Size = new System.Drawing.Size(100, 27);
            this.txtParaUstu.TabIndex = 3;
            this.txtParaUstu.Text = "4,75";
            this.txtParaUstu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtOdenen
            // 
            this.txtOdenen.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtOdenen.Location = new System.Drawing.Point(361, 34);
            this.txtOdenen.Name = "txtOdenen";
            this.txtOdenen.Size = new System.Drawing.Size(100, 27);
            this.txtOdenen.TabIndex = 3;
            this.txtOdenen.Text = "30,00";
            this.txtOdenen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtOdenen.TextChanged += new System.EventHandler(this.txtOdenen_TextChanged);
            // 
            // comboOdeme
            // 
            this.comboOdeme.FormattingEnabled = true;
            this.comboOdeme.Items.AddRange(new object[] {
            "Nakit",
            "Kredi Kartı"});
            this.comboOdeme.Location = new System.Drawing.Point(115, 41);
            this.comboOdeme.Name = "comboOdeme";
            this.comboOdeme.Size = new System.Drawing.Size(117, 24);
            this.comboOdeme.TabIndex = 2;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(264, 96);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 16);
            this.label23.TabIndex = 1;
            this.label23.Text = "Para Üstü";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(259, 37);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(73, 16);
            this.label22.TabIndex = 1;
            this.label22.Text = "Ödenen(f3)";
            // 
            // lblToplamTutar
            // 
            this.lblToplamTutar.BackColor = System.Drawing.Color.Red;
            this.lblToplamTutar.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamTutar.Location = new System.Drawing.Point(203, 79);
            this.lblToplamTutar.Name = "lblToplamTutar";
            this.lblToplamTutar.Size = new System.Drawing.Size(175, 33);
            this.lblToplamTutar.TabIndex = 3;
            this.lblToplamTutar.Text = "25,25";
            this.lblToplamTutar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(14, 79);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(95, 24);
            this.label21.TabIndex = 1;
            this.label21.Text = "Nakit(F1)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 44);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 16);
            this.label19.TabIndex = 1;
            this.label19.Text = "Ödeme Türü";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(162, 4);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(204, 27);
            this.label18.TabIndex = 0;
            this.label18.Text = "ÖDEME BÖLÜMÜ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 370);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1349, 191);
            this.panel3.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Sil,
            this.Arttır,
            this.Azalt});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1349, 191);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblKayitSayisi);
            this.panel1.Controls.Add(this.btnYapılanSatislar);
            this.panel1.Controls.Add(this.btnFiyatGor);
            this.panel1.Controls.Add(this.btnUrunIade);
            this.panel1.Controls.Add(this.btnMusteriBorc);
            this.panel1.Controls.Add(this.btnAnaSayfa);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 704);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1349, 98);
            this.panel1.TabIndex = 3;
            // 
            // lblKayitSayisi
            // 
            this.lblKayitSayisi.AutoSize = true;
            this.lblKayitSayisi.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKayitSayisi.Location = new System.Drawing.Point(721, 27);
            this.lblKayitSayisi.Name = "lblKayitSayisi";
            this.lblKayitSayisi.Size = new System.Drawing.Size(279, 27);
            this.lblKayitSayisi.TabIndex = 1;
            this.lblKayitSayisi.Text = "Toplam 5 kayıt listelendi";
            // 
            // btnYapılanSatislar
            // 
            this.btnYapılanSatislar.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnYapılanSatislar.Location = new System.Drawing.Point(490, 15);
            this.btnYapılanSatislar.Name = "btnYapılanSatislar";
            this.btnYapılanSatislar.Size = new System.Drawing.Size(96, 57);
            this.btnYapılanSatislar.TabIndex = 0;
            this.btnYapılanSatislar.Text = "Yapılan Satışlar(f9)";
            this.btnYapılanSatislar.UseVisualStyleBackColor = false;
            // 
            // btnFiyatGor
            // 
            this.btnFiyatGor.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnFiyatGor.Location = new System.Drawing.Point(378, 15);
            this.btnFiyatGor.Name = "btnFiyatGor";
            this.btnFiyatGor.Size = new System.Drawing.Size(96, 57);
            this.btnFiyatGor.TabIndex = 0;
            this.btnFiyatGor.Text = "Fiyat Gör(f8)";
            this.btnFiyatGor.UseVisualStyleBackColor = false;
            // 
            // btnUrunIade
            // 
            this.btnUrunIade.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnUrunIade.Location = new System.Drawing.Point(255, 15);
            this.btnUrunIade.Name = "btnUrunIade";
            this.btnUrunIade.Size = new System.Drawing.Size(96, 57);
            this.btnUrunIade.TabIndex = 0;
            this.btnUrunIade.Text = "Ürün İade(f7)";
            this.btnUrunIade.UseVisualStyleBackColor = false;
            // 
            // btnAnaSayfa
            // 
            this.btnAnaSayfa.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnAnaSayfa.Location = new System.Drawing.Point(6, 15);
            this.btnAnaSayfa.Name = "btnAnaSayfa";
            this.btnAnaSayfa.Size = new System.Drawing.Size(96, 57);
            this.btnAnaSayfa.TabIndex = 0;
            this.btnAnaSayfa.Text = "Ana Sayfa";
            this.btnAnaSayfa.UseVisualStyleBackColor = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(115, 79);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(143, 24);
            this.label20.TabIndex = 1;
            this.label20.Text = "Kredi Kartı(f2)";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lblToplamTutar);
            this.panel4.Controls.Add(this.lblKdv);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(572, 121);
            this.panel4.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64.97545F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.02455F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 135F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1357, 806);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.21361F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.78639F));
            this.tableLayoutPanel2.Controls.Add(this.panelMusteri, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panelUrun, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1349, 359);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // panelMusteri
            // 
            this.panelMusteri.Controls.Add(this.label4);
            this.panelMusteri.Controls.Add(this.label3);
            this.panelMusteri.Controls.Add(this.label2);
            this.panelMusteri.Controls.Add(this.label1);
            this.panelMusteri.Controls.Add(this.txtEmail);
            this.panelMusteri.Controls.Add(this.txtAdSoyad);
            this.panelMusteri.Controls.Add(this.txtTelefon);
            this.panelMusteri.Controls.Add(this.txtMusteriIdAra);
            this.panelMusteri.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMusteri.Location = new System.Drawing.Point(4, 4);
            this.panelMusteri.Name = "panelMusteri";
            this.panelMusteri.Size = new System.Drawing.Size(427, 351);
            this.panelMusteri.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "E mail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Telefon";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ad Soyad";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Müşteri ID Ara";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(155, 114);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(118, 22);
            this.txtEmail.TabIndex = 0;
            // 
            // txtAdSoyad
            // 
            this.txtAdSoyad.Location = new System.Drawing.Point(155, 48);
            this.txtAdSoyad.Name = "txtAdSoyad";
            this.txtAdSoyad.Size = new System.Drawing.Size(118, 22);
            this.txtAdSoyad.TabIndex = 0;
            // 
            // txtTelefon
            // 
            this.txtTelefon.Location = new System.Drawing.Point(155, 81);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(118, 22);
            this.txtTelefon.TabIndex = 0;
            // 
            // txtMusteriIdAra
            // 
            this.txtMusteriIdAra.BackColor = System.Drawing.Color.Yellow;
            this.txtMusteriIdAra.Location = new System.Drawing.Point(155, 15);
            this.txtMusteriIdAra.Name = "txtMusteriIdAra";
            this.txtMusteriIdAra.Size = new System.Drawing.Size(118, 22);
            this.txtMusteriIdAra.TabIndex = 0;
            this.txtMusteriIdAra.TextChanged += new System.EventHandler(this.txtMusteriIdAra_TextChanged);
            // 
            // panelUrun
            // 
            this.panelUrun.Controls.Add(this.btnSepeteEkle);
            this.panelUrun.Controls.Add(this.btnTemizle);
            this.panelUrun.Controls.Add(this.label8);
            this.panelUrun.Controls.Add(this.txtToplamFiyat);
            this.panelUrun.Controls.Add(this.label11);
            this.panelUrun.Controls.Add(this.label7);
            this.panelUrun.Controls.Add(this.label10);
            this.panelUrun.Controls.Add(this.label6);
            this.panelUrun.Controls.Add(this.txtMarka);
            this.panelUrun.Controls.Add(this.label9);
            this.panelUrun.Controls.Add(this.label5);
            this.panelUrun.Controls.Add(this.txtKdv);
            this.panelUrun.Controls.Add(this.txtBirimFiyat);
            this.panelUrun.Controls.Add(this.txtMiktar);
            this.panelUrun.Controls.Add(this.txtUrun);
            this.panelUrun.Controls.Add(this.txtMalId);
            this.panelUrun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUrun.Location = new System.Drawing.Point(438, 4);
            this.panelUrun.Name = "panelUrun";
            this.panelUrun.Size = new System.Drawing.Size(907, 351);
            this.panelUrun.TabIndex = 1;
            this.panelUrun.Paint += new System.Windows.Forms.PaintEventHandler(this.panelUrun_Paint);
            // 
            // btnSepeteEkle
            // 
            this.btnSepeteEkle.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnSepeteEkle.Location = new System.Drawing.Point(548, 79);
            this.btnSepeteEkle.Name = "btnSepeteEkle";
            this.btnSepeteEkle.Size = new System.Drawing.Size(85, 54);
            this.btnSepeteEkle.TabIndex = 2;
            this.btnSepeteEkle.Text = "Sepete Ekle";
            this.btnSepeteEkle.UseVisualStyleBackColor = false;
            this.btnSepeteEkle.Click += new System.EventHandler(this.btnSepeteEkle_Click);
            // 
            // btnTemizle
            // 
            this.btnTemizle.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnTemizle.Location = new System.Drawing.Point(548, 15);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(85, 52);
            this.btnTemizle.TabIndex = 2;
            this.btnTemizle.Text = "Temizle";
            this.btnTemizle.UseVisualStyleBackColor = false;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 119);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Birim Fiyat";
            // 
            // txtToplamFiyat
            // 
            this.txtToplamFiyat.Location = new System.Drawing.Point(397, 45);
            this.txtToplamFiyat.Name = "txtToplamFiyat";
            this.txtToplamFiyat.Size = new System.Drawing.Size(80, 22);
            this.txtToplamFiyat.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(271, 81);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 16);
            this.label11.TabIndex = 1;
            this.label11.Text = "Kdv";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Ürün";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(271, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Toplam Fiyat";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Marka";
            // 
            // txtMarka
            // 
            this.txtMarka.Location = new System.Drawing.Point(138, 45);
            this.txtMarka.Name = "txtMarka";
            this.txtMarka.Size = new System.Drawing.Size(107, 22);
            this.txtMarka.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(271, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "Miktar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mal ID Ara";
            // 
            // txtKdv
            // 
            this.txtKdv.Location = new System.Drawing.Point(397, 78);
            this.txtKdv.Name = "txtKdv";
            this.txtKdv.Size = new System.Drawing.Size(80, 22);
            this.txtKdv.TabIndex = 0;
            // 
            // txtBirimFiyat
            // 
            this.txtBirimFiyat.Location = new System.Drawing.Point(138, 111);
            this.txtBirimFiyat.Name = "txtBirimFiyat";
            this.txtBirimFiyat.Size = new System.Drawing.Size(107, 22);
            this.txtBirimFiyat.TabIndex = 0;
            // 
            // txtMiktar
            // 
            this.txtMiktar.Location = new System.Drawing.Point(397, 12);
            this.txtMiktar.Name = "txtMiktar";
            this.txtMiktar.Size = new System.Drawing.Size(80, 22);
            this.txtMiktar.TabIndex = 0;
            this.txtMiktar.TextChanged += new System.EventHandler(this.txtMiktar_TextChanged);
            // 
            // txtUrun
            // 
            this.txtUrun.Location = new System.Drawing.Point(138, 78);
            this.txtUrun.Name = "txtUrun";
            this.txtUrun.Size = new System.Drawing.Size(107, 22);
            this.txtUrun.TabIndex = 0;
            // 
            // txtMalId
            // 
            this.txtMalId.BackColor = System.Drawing.Color.Yellow;
            this.txtMalId.Location = new System.Drawing.Point(138, 12);
            this.txtMalId.Name = "txtMalId";
            this.txtMalId.Size = new System.Drawing.Size(107, 22);
            this.txtMalId.TabIndex = 0;
            this.txtMalId.TextChanged += new System.EventHandler(this.txtMalId_TextChanged);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.98019F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.01981F));
            this.tableLayoutPanel3.Controls.Add(this.panel4, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(4, 568);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1349, 129);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.btnSatisIptal);
            this.panel5.Controls.Add(this.btnSatisOnay);
            this.panel5.Controls.Add(this.txtParaUstu);
            this.panel5.Controls.Add(this.txtOdenen);
            this.panel5.Controls.Add(this.comboOdeme);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(583, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(762, 121);
            this.panel5.TabIndex = 1;
            // 
            // Sil
            // 
            this.Sil.HeaderText = "Sil";
            this.Sil.MinimumWidth = 6;
            this.Sil.Name = "Sil";
            this.Sil.Width = 125;
            // 
            // Arttır
            // 
            this.Arttır.HeaderText = "Arttır";
            this.Arttır.MinimumWidth = 6;
            this.Arttır.Name = "Arttır";
            this.Arttır.Width = 125;
            // 
            // Azalt
            // 
            this.Azalt.HeaderText = "Azalt";
            this.Azalt.MinimumWidth = 6;
            this.Azalt.Name = "Azalt";
            this.Azalt.Width = 125;
            // 
            // frmSatisYap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1357, 806);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmSatisYap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SATIŞ SAYFASI";
            this.Load += new System.EventHandler(this.frmSatisYap_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmSatisYap_KeyDown);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panelMusteri.ResumeLayout(false);
            this.panelMusteri.PerformLayout();
            this.panelUrun.ResumeLayout(false);
            this.panelUrun.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMusteriBorc;
        private System.Windows.Forms.Label lblKdv;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnSatisIptal;
        private System.Windows.Forms.Button btnSatisOnay;
        private System.Windows.Forms.TextBox txtParaUstu;
        private System.Windows.Forms.TextBox txtOdenen;
        private System.Windows.Forms.ComboBox comboOdeme;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblToplamTutar;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblKayitSayisi;
        private System.Windows.Forms.Button btnYapılanSatislar;
        private System.Windows.Forms.Button btnFiyatGor;
        private System.Windows.Forms.Button btnUrunIade;
        private System.Windows.Forms.Button btnAnaSayfa;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panelMusteri;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtAdSoyad;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.TextBox txtMusteriIdAra;
        private System.Windows.Forms.Panel panelUrun;
        private System.Windows.Forms.Button btnSepeteEkle;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtToplamFiyat;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMarka;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKdv;
        private System.Windows.Forms.TextBox txtBirimFiyat;
        private System.Windows.Forms.TextBox txtMiktar;
        private System.Windows.Forms.TextBox txtUrun;
        private System.Windows.Forms.TextBox txtMalId;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Arttır;
        private System.Windows.Forms.DataGridViewTextBoxColumn Azalt;
    }
}