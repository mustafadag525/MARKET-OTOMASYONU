﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proje_.Classlar
{
    public class Veritabanı
    {
       public static string strbaglanti = "Data Source=LAPTOP-B6OIA1UJ;Initial Catalog=gıda;Integrated Security=True;Pooling=False";

    }
}
